#pragma once

void loadWiFiCredentials(char* ssid, char* pass);
void saveWiFiCredentials(const char* ssid, const char* pass);
bool hasWiFiCredentials();