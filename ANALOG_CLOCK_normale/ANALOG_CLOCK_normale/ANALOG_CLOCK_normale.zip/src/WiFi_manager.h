//   wifi_manager.h    //

#pragma once

#include <Arduino.h>

void initWiFi();
void updateWiFi();

bool isWiFiConnected();
bool isAPMode();

bool setWiFiProfile(uint8_t index);

uint8_t getWiFiProfileCount(void);

const char* getWiFiProfileSSID(uint8_t index);

