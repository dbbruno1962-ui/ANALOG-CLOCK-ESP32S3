#include "WiFi_manager.h"
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <time.h>
#include "config.h"
#include "ui_state.h"
#include "wifi_profiles.h"
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>


/* =========================
   STATE
========================= */

enum wifi_state_t {
    WIFI_BOOT,
    WIFI_STA_CONNECTING,
    WIFI_STA_OK,
    WIFI_AP_MODE
};

static wifi_state_t wifi_state = WIFI_BOOT;

/* =========================
   STORAGE + SERVER
========================= */

static Preferences wifi_prefs;
static WebServer server(80);

static BLECharacteristic* ble_tx = nullptr;
static BLECharacteristic* ble_rx = nullptr;

static String ble_cmd = "";
static bool ble_new_cmd = false;

#define BLE_SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define BLE_CHARACTERISTIC_TX   "beb5483e-36e1-4688-b7f5-ea07361b26a8"
#define BLE_CHARACTERISTIC_RX   "6e400002-b5a3-f393-e0a9-e50e24dcca9e"


static bool ap_started = false;

static unsigned long wifi_start_ms = 0;
static unsigned long ap_start_ms = 0;
static unsigned long last_ntp_sync_ms = 0;

static bool ntp_done = false;
static bool time_valid = false;

static bool bt_started = false;
static unsigned long bt_start_ms = 0;

/* =========================
   WIFI PROFILE
========================= */

bool setWiFiProfile(uint8_t index)
{
    if (index >= WIFI_PROFILE_COUNT) {

        Serial.println("[WIFI] invalid profile");

        return false;
    }

    wifi_prefs.begin("wifi", false);

    wifi_prefs.putUChar("profile", index);

    wifi_prefs.end();

    Serial.print("[WIFI] selected profile: ");
    Serial.println(wifi_profiles[index].ssid);

    return true;
}

/* =========================
   BT CONFIG
========================= */
class BLECmdCallback : public BLECharacteristicCallbacks
{
    void onWrite(BLECharacteristic *pCharacteristic)
    {
        String rx =
            pCharacteristic->getValue().c_str();

        rx.trim();

        if (rx.length())
        {
            ble_cmd = rx;

            ble_new_cmd = true;

            Serial.print("[BLE] ");

            Serial.println(ble_cmd);
        }
    }
};

void bt_start_config()
{
    if (bt_started) return;

    BLEDevice::init(USER_FIN);

    BLEServer *server =
        BLEDevice::createServer();

    BLEService *service =
        server->createService(
            BLE_SERVICE_UUID
        );

    ble_tx =
        service->createCharacteristic(
            BLE_CHARACTERISTIC_TX,
            BLECharacteristic::PROPERTY_NOTIFY
        );

    ble_tx->addDescriptor(
        new BLE2902()
    );

    ble_rx =
        service->createCharacteristic(
            BLE_CHARACTERISTIC_RX,
            BLECharacteristic::PROPERTY_WRITE
        );

    ble_rx->setCallbacks(
        new BLECmdCallback()
    );

    service->start();

    BLEAdvertising *advertising =
        BLEDevice::getAdvertising();

    advertising->start();

    Serial.println("[BLE] active");

    bt_started = true;

    bt_start_ms = millis();
}



void bt_stop_config()
{
    if (!bt_started) return;

    BLEDevice::deinit(true);

    bt_started = false;

    Serial.println("[BLE] stopped");
}

void bt_handle_config()
{
    if (!bt_started) return;

    if (millis() - bt_start_ms > 600000UL)
    {
        bt_stop_config();
        return;
    }

if (!ble_new_cmd) return;

String cmd = ble_cmd;

ble_new_cmd = false;


    cmd.trim();

    cmd.toUpperCase();

  
    /* =========================
       LIST
    ========================= */

    if (cmd == "LIST")
    {
        for (uint8_t i = 0;
             i < WIFI_PROFILE_COUNT;
             i++)
        {
            String msg =
                String(i) +
                " -> " +
                wifi_profiles[i].ssid;

            ble_tx->setValue(
                msg.c_str()
            );

            ble_tx->notify();

            delay(50);
        }

        return;
    }


     /* =========================
       STATUS
    ========================= */

    if (cmd == "STATUS")
    {
        String msg = "WiFi: ";

        if (WiFi.status() == WL_CONNECTED)
        {
            msg += "CONNECTED ";

            msg += WiFi.localIP().toString();
        }
        else
        {
            msg += "DISCONNECTED";
        }

        ble_tx->setValue(msg.c_str());

        ble_tx->notify();

        return;
    }

    /* =========================
       USE n
    ========================= */

    if (cmd.startsWith("USE "))
    {
        String num =
            cmd.substring(4);

        uint8_t index =
            num.toInt();

        if (setWiFiProfile(index))
        {
            ble_tx->setValue("OK REBOOT");

            ble_tx->notify();

            delay(1000);

            ESP.restart();
        }
        else
        {
            ble_tx->setValue("INVALID");

            ble_tx->notify();
        }

        return;
    }

    ble_tx->setValue("UNKNOWN");

    ble_tx->notify();
}



/* =========================
   WEB SERVER
========================= */

void start_http_server()
{
    server.on("/", HTTP_GET, []() {

        server.send(
            200,
            "text/html",

            "<meta name='viewport' content='width=device-width'>"

            "<h2>Clock WiFi Setup</h2>"

            "<form action='/save'>"

            "SSID<br>"
            "<input name='s'><br><br>"

            "Password<br>"
            "<input name='p' type='password'><br><br>"

            "<button>Save</button>"

            "</form>"
        );
    });

    server.on("/save", HTTP_GET, []() {

        if (server.hasArg("s"))
        {
            wifi_prefs.begin("wifi", false);

            wifi_prefs.putString(
                "ssid",
                server.arg("s")
            );

            wifi_prefs.putString(
                "pass",
                server.arg("p")
            );

            wifi_prefs.end();

            server.send(
                200,
                "text/plain",
                "Saved. Rebooting..."
            );

            delay(500);

            ESP.restart();
        }
        else
        {
            server.send(
                400,
                "text/plain",
                "Missing SSID"
            );
        }
    });

    server.begin();
}

/* =========================
   WIFI FUNCTIONS
========================= */

void wifi_start_sta()
{
    wifi_prefs.begin("wifi", true);

    uint8_t profile =
        wifi_prefs.getUChar("profile", 0);

    wifi_prefs.end();

    if (profile >= WIFI_PROFILE_COUNT)
        profile = 0;

    Serial.print("[WIFI] profile: ");

    Serial.println(
        wifi_profiles[profile].ssid
    );

    WiFi.mode(WIFI_STA);

    WiFi.begin(
        wifi_profiles[profile].ssid,
        wifi_profiles[profile].password
    );

    wifi_state = WIFI_STA_CONNECTING;

    wifi_start_ms = millis();
}

void wifi_start_ap()
{
    if (ap_started) return;

    WiFi.mode(WIFI_AP);

    delay(100);

    WiFi.softAP("Clock_Setup");

    start_http_server();

    q8_enter_ap_mode(
        WiFi.softAPIP().toString().c_str(),
        "12345678"
    );

    ap_started = true;

    ap_start_ms = millis();
}

void wifi_stop_ap()
{
    if (!ap_started) return;

    WiFi.softAPdisconnect(true);

    ap_started = false;
}

void handle_ap_timeout()
{
    if (!ap_started) return;

    if (millis() - ap_start_ms >=
        (15UL * 60UL * 1000UL))
    {
        ESP.restart();
    }
}

void handle_ntp()
{
    if (wifi_state != WIFI_STA_OK)
        return;

    if (!ntp_done)
    {
        configTime(
            GMT_OFFSET_SEC,
            DAYLIGHT_OFFSET_SEC,
            NTP_SERVER
        );

        time_valid = true;

        ntp_done = true;

        last_ntp_sync_ms = millis();
    }

    if (millis() - last_ntp_sync_ms >=
        (24UL * 60UL * 60UL * 1000UL))
    {
        configTime(
            GMT_OFFSET_SEC,
            DAYLIGHT_OFFSET_SEC,
            NTP_SERVER
        );

        last_ntp_sync_ms = millis();
    }
}

/* =========================
   PUBLIC API
========================= */

void initWiFi()
{
    wifi_state = WIFI_BOOT;
}

void updateWiFi()
{
    bt_handle_config();

    if (ap_started)
    {
        server.handleClient();

        handle_ap_timeout();
    }

    handle_ntp();

    switch (wifi_state)
    {
        case WIFI_BOOT:

            bt_start_config();

            wifi_start_sta();

            break;

        case WIFI_STA_CONNECTING:

            if (WiFi.status() ==
                WL_CONNECTED)
            {
                Serial.println(
                    "[WIFI] connected"
                );

                wifi_state =
                    WIFI_STA_OK;
            }
            else if (
                millis() - wifi_start_ms >
                WIFI_TIMEOUT_MS)
            {
                Serial.println(
                    "[WIFI] timeout"
                );

                wifi_state =
                    WIFI_AP_MODE;
            }

            break;

        case WIFI_STA_OK:

            wifi_stop_ap();

            break;

        case WIFI_AP_MODE:

            wifi_start_ap();

            break;
    }
}

bool isWiFiConnected()
{
    return WiFi.status() ==
           WL_CONNECTED;
}

bool isAPMode()
{
    return wifi_state ==
           WIFI_AP_MODE;
}

uint8_t getWiFiProfileCount(void)
{
    return WIFI_PROFILE_COUNT;
}

const char* getWiFiProfileSSID(
    uint8_t index)
{
    if (index >= WIFI_PROFILE_COUNT)
        return "";

    return wifi_profiles[index].ssid;
}