#include "wifi_storage.h"
#include <Preferences.h>

static Preferences prefs;

#define NAMESPACE "wifi"

void loadWiFiCredentials(char* ssid, char* pass)
{
    prefs.begin(NAMESPACE, true);

    String s = prefs.getString("ssid", "");
    String p = prefs.getString("pass", "");

    prefs.end();

    strcpy(ssid, s.c_str());
    strcpy(pass, p.c_str());
}

void saveWiFiCredentials(const char* ssid, const char* pass)
{
    prefs.begin(NAMESPACE, false);

    prefs.putString("ssid", ssid);
    prefs.putString("pass", pass);

    prefs.end();
}

bool hasWiFiCredentials()
{
    prefs.begin(NAMESPACE, true);

    bool ok = prefs.isKey("ssid") && prefs.isKey("pass");

    prefs.end();
    return ok;
}